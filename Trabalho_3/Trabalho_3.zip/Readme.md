## Participantes
Leonardo Augusto, 278998, Turma B

Giusepe Tessari, 282772, Turma B

Maurício Kritli, 232807, Turma A

## Parâmetros do algoritmo genético
 (g, n, k, m, e) que resultam no menor número de ataques entre rainhas:

* g = 20
* n = 50
* k = 8
* m = 0.7
* e = True

## Valores da melhor execução da regressão linear
* theta_0 = -5
* theta_1 = -5
* alpha = 0.001
* num_iterations = 20000

## Melhor erro quadrático médio obtido

* EQM = 8.953942774531923